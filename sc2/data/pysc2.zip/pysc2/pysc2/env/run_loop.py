# Copyright 2017 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS-IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""A run loop for agent/environment interaction."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
import time
import numpy as np
np.set_printoptions(threshold=sys.maxsize)

from pysc2.lib.actions import FUNCTIONS

def screen_to_str(timestep):
    screen = timestep.observation.feature_screen.unit_type
    screen = np.array(screen)

    screen_str = []
    for row in screen:
        screen_str += str(row) + '\n'
    return screen_str


def stepper(episode, frame, timestep, actions, _check=0):
    available_actions = timestep.observation.available_actions
    last_actions = timestep.observation.last_actions
    reward = timestep.reward
    done = timestep.last()

    print('[ Episode : {} ]  < frame : {} >\n'.format(episode, frame))
    print('++++++++++++++++++++++++++++++++++')
    print('| Reward : {}'.format(reward))
    print('| Done   : {}'.format(done))
    print('++++++++++++++++++++++++++++++++++')
    print('Available actions:')
    for a in available_actions:
        if a in [93, 94, 95, 96, 97, 98, 99]:
            _check = True
        print('\t[ action ID : {} ] - {}'.format(a, FUNCTIONS[a].name))
    print('++++++++++++++++++++++++++++++++++')
    print('Last actions:')
    for a in last_actions:
        print('\t[ action ID : {} ] - {}'.format(a, FUNCTIONS[a].name))
    print('++++++++++++++++++++++++++++++++++')
    print('Agent action:')
    #for a in actions:
    #    if len(a.arguments) == 2:
    #        try:
    #            print('\t[ action ID : {} ] - {} (x: {}, y: {})'.format(a.function.value, a.function.name, a.arguments[1][0], a.arguments[1][1]))
    #        except IndexError:
    #            from IPython import embed; embed()

    #    print('\t[ action ID : {} ] - {}'.format(a.function.value, a.function.name))
        #if a.function == 91 or a.function == 451:
        #    queued = a.arguments[0][0]
        #    _y, _x = a.arguments[1][0], a.arguments[1][1]
        #    print('\t[ action ID : {} ] - {} [{}] (y: {}, x: {})'.format(a.function, FUNCTIONS[a.function].name, queued, _y, _x))
        #else:
        #    print('\t[ action ID : {} ] - {}'.format(a.function, FUNCTIONS[a.function].name))
    print('++++++++++++++++++++++++++++++++++')

    if done:
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        print("@@@@@@@@@@@@@@@@@@@@@@@@ DONE @@@@@@@@@@@@@@@@@@@@@@@@@@")
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        #if not reward:
        #    from IPython import embed; embed()

    return _check

def run_loop(agents, env, max_frames=0, max_episodes=0):
  """A run loop to have agents and an environment interact."""
  total_frames = 0
  total_episodes = 0
  epi_length = 0
  start_time = time.time()

  observation_spec = env.observation_spec()
  action_spec = env.action_spec()
  for agent, obs_spec, act_spec in zip(agents, observation_spec, action_spec):
    agent.setup(obs_spec, act_spec)

  _check = False
  try:
    while not max_episodes or total_episodes < max_episodes:
      total_episodes += 1
      timesteps = env.reset()
      #from IPython import embed; embed()
      for a in agents:
        a.reset()
      while True:
        epi_length += 1
        total_frames += 1
        actions = [agent.step(timestep)
                   for agent, timestep in zip(agents, timesteps)]

        # Logger
        timestep = timesteps[0]
        _check = stepper(total_episodes, total_frames, timestep, actions, _check)
        #if _check:
        #  #if _check and counter > 0:
        #  from IPython import embed; embed()
        #  counter -= 1
        #  _check = False
        #else:
        #  counter = 5
        #  _check = False

        #scr = screen_to_str(timestep)
        avail_acts = timestep.observation.available_actions
        last_acts = timestep.observation.last_actions
        #if (91 in avail_acts) and (91 == actions[0].function) and (len(last_acts) == 0):
        #    from IPython import embed; embed()
        #    actions = [agent.step(timestep, issue=True)
        #           for agent, timestep in zip(agents, timesteps)]
        #    actions = [FUNCTIONS.select_point("select", actions[0].arguments[1])]
        #    from IPython import embed; embed()

        if timesteps[0].first():
            from IPython import embed; embed()

        if timesteps[0].reward != 0:
            from IPython import embed; embed()

        if max_frames and total_frames >= max_frames:
          return
        if timesteps[0].last():
          from IPython import embed; embed()
          epi_length = 0
          break
        timesteps = env.step(actions)
        #from IPython import embed; embed()
  except KeyboardInterrupt:
    pass
  finally:
    elapsed_time = time.time() - start_time
    print("Took %.3f seconds for %s steps: %.3f fps" % (
        elapsed_time, total_frames, total_frames / elapsed_time))
